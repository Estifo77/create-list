/* tslint:disable */
require('./Hello.module.css');
const styles = {
  hello: 'hello_efddbf0d',
  container: 'container_efddbf0d',
  row: 'row_efddbf0d',
  column: 'column_efddbf0d',
  'ms-Grid': 'ms-Grid_efddbf0d',
  title: 'title_efddbf0d',
  subTitle: 'subTitle_efddbf0d',
  description: 'description_efddbf0d',
  button: 'button_efddbf0d',
  label: 'label_efddbf0d',
};

export default styles;
/* tslint:enable */