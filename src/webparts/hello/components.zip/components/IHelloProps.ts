import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IHelloProps {
  description: string;
  context: WebPartContext;
}
